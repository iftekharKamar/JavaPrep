package leacture.xtra;
import java.util.*;

public class Intro {
    public static void main(String[] args) {
//        Scanner sc = new Scanner(System.in);
//        float a = sc.nextFloat();
//        float area = 3.14f*a*a;
//        System.out.print(area);
//      System.out.print("1 2 3 4 5");

//        char a = '@';
//         int b =(int)a;
//
//        int x = 2, y = 5;
//        int exp1 = (x * y / x);
//        int exp2 = (y / x);
//        System.out.print(exp1 +",");
//        System.out.print(exp2);
//        Scanner sc = new Scanner(System.in);
//        int income = sc.nextInt();
//        int Tax;
//        if(income>=500000&&income<1000000){
//            Tax = (int)(income*0.2);
//            System.out.println(Tax);
//
//        }else if(income>1000000){
//            Tax =(int)(income*0.3) ;
//            System.out.println(Tax);
//
//        }else{
//            System.out.println("0");
//        }
//    }

        int marks = 12;
        String res = (marks>=33)?"Pass":"fail";
        System.out.print(res);


    }
}
