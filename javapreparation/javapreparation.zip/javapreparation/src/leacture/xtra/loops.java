package leacture.xtra;

import java.util.*;

public class loops {
    public static void main(String[] args) {
//        int  c=0;
//        while(c<5){
//            System.out.println("hella");
//            c++;
//        }

        Scanner sc = new Scanner(System.in);
//        int rev =0;
//        int num =sc.nextInt();
//        while(num>0){
//            int lastdigit = num%10;
//            rev = (rev*10)+lastdigit;
//            num =num/10;
//        }
//        System.out.print(rev);
//
        for(int i=0;i<5;i++)
        {
            System.out.println("Hello");
        i+=2;
        }
    }
}
