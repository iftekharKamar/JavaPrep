package leacture.OOPS;

import javax.swing.text.html.StyleSheet;

public class Polymorphism {
    public static void main(String[] args) {
//        Claculator calc = new Claculator();
//        System.out.println(calc.sum(1,2));
//        System.out.println(calc.sum(1.5f,2.5f));
//        System.out.println(calc.sum(1,2,3));

//        Deer deer = new Deer();
//        deer.eat();
    }
}

    //Method OverLoading
//   class Claculator{
//        int sum(int a,int b){
//            return a+b;
//        }
//        float sum(float a, float b){
//            return a+b;
//        }
//
//        int sum (int a, int b,int c){
//            return a+b+c;
//        }
//
//    }
//
//    //Method Overriding
//    class Animals{
//        void eat(){
//            System.out.println("Eat");
//        }
//    }
//
//  class Deer extends Animals{
//        void eat(){
//            System.out.print("Eat grass");
//        }
//    }
//
