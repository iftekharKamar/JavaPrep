package leacture.OOPS;

public class PracticeQuestion {


    public static void main(String[] args) {

    }
}
