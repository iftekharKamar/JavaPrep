package leacture.OOPS;

import javax.swing.*;

public class Abstrac {
    public static void main(String[] args) {

    }

}
//abstraction
//abstract class Animal{
//String color;
//    Animal(){
//     color ="brown";
//    }
//    void eat(){
//        System.out.println("animal eats");
//    }
//    abstract void walk();
//}
//class Horse extends Animal{
//    void chandeColor(){
//        color ="Black";
//    }
//    void walk(){
//        System.out.println("walks on 4 legs");
//    }
//}

