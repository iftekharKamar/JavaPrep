package leacture.OOPS;

import java.util.logging.Handler;

public class Inheritance {
    public static void main(String[] args) {
//        Dog labra = new Dog();
//        labra.eat();
//        labra.legs = 4;
//        System.out.println(labra.legs);
    }
}

//   class Animal{
//        String color ;
//        void eat(){
//            System.out.println("Eats");
//        }
//        void breath(){
//            System.out.println("breath");
//        }
//    }
//   class Fish extends Animal{
//        int fins;
//
//        void swim(){
//            System.out.println("Swim in watre");
//        }
//    }
//
//  class mammals extends Animal{
//        int legs;
//    }
//
//   class Dog extends mammals{
//        String breed;
//    }

